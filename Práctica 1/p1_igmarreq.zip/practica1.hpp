// *********************************************************************
// **
// ** Informática Gráfica, curso 2014-15
// ** 
// **
// ** Práctica 1  (declaraciones públicas)
// **
// *********************************************************************

#ifndef IG_PRACTICA1_HPPSS
#define IG_PRACTICA1_HPPSS


void P1_DibujarObjetos(int modo) ; 
void P1_Inicializar( int argc, char *argv[] ) ;


#endif
