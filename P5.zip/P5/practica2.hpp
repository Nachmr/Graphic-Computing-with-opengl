// *********************************************************************
// **
// ** Informática Gráfica, curso 2014-15
// ** 
// **
// ** Práctica 2  (declaraciones públicas)
// **
// *********************************************************************

#ifndef IG_PRACTICA2_HPPSS
#define IG_PRACTICA2_HPPSS


void P2_DibujarObjetos(char modo) ; 
void P2_Inicializar( int argc, char *argv[] ) ;


#endif
